from rest_framework import serializers
from .models import *
from rest_framework.serializers import ModelSerializer


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'email']
        
class BookSerializer(ModelSerializer):
    class Meta:
        model = Book
        fields = ['id', 'user', 'name', 'description', 'price', 'is_borrow', 'from_date', 'to_date']
        
class BookListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Book
        fields = ['id', 'name']
        
class BorrowHistorySerializer(serializers.ModelSerializer):
    user_email = serializers.EmailField(source='user.email', read_only=True)
    book_name = serializers.CharField(source='book.name', read_only=True)
    class Meta:
        model = BorrowHistory
        fields = ['user_email', 'book_name', 'borrowed_on', 'returned_on', 'status']
